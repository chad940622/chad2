/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
double Power(double, int); 
void main(void)
{
int k;
double Ans;
printf( "計算3.5的k次方？請輸入k=")；
scanf( "%d",&k); Ans=Fowe r(3.5,k);
printf（"3.5的sd次方=Bfln”,k,Ans);
system( "pause");
}
double Power( double X, int n)
{
int i; double PowerXn=l;
for(i=1;i<=n; i++)
PowerXn=PowerXn*X;
return PowerXn;
}