/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int square(int y);

int main(void)
{
    int x;
    for(x=1;x<=10;x++)
    {
        printf("%d ",square(x));
    }
    printf("\n");
    system("pause");
    return 0;
}
int square(int y)
{
    return y*y;
}
