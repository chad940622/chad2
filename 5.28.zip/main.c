/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    char inputChar, resultChar;

    printf("请输入一个字母字符: ");
    scanf("%c", &inputChar);

    if (inputChar >= 'a' && inputChar <= 'z') {
        resultChar = inputChar - 'a' + 'A';
    } else if (inputChar >= 'A' && inputChar <= 'Z') {
        resultChar = inputChar - 'A' + 'a';
    } else {
        resultChar = inputChar;  
    }

    printf("大小写互换后的字符是: %c\n", resultChar);

    return 0;
}





