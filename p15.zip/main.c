/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
int maximum (int x, int y, int z);
int main(void)
{
int numberl; int number2; int number3;
printf("Enter three integers:");
scanf("%d %d %d",&number1,&number2,&number3);
printf( "Maximum is: %d\n", maximum(numberl, number2, number3));
system ("pause");
return 0;
}
int maximund (int x, int y, int z)
{
int max=x;
if(y>max)
max=y;
if( z>max)
max=z；
return max;
}